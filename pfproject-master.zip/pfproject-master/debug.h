#ifndef DEBUG_H
#define DEBUG_H

void DEBUG_printCandy(int candy);

void DEBUG_printGrid(int grid[ROWS][COLS]);

#endif
